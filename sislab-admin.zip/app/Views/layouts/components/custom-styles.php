
        <!-- Style Css -->
        <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">

        <!-- Simplebar Css -->
        <link rel="stylesheet" href="<?php echo base_url('assets/libs/simplebar/simplebar.min.css'); ?>">

        <!-- Color Picker Css -->
        <link rel="stylesheet" href="<?php echo base_url('assets/libs/@simonwep/pickr/themes/nano.min.css'); ?>">

		<?= $this->renderSection('styles'); ?>