<!-- Back To Top -->
<div class="scrollToTop">
    <span class="arrow"><i class="ri-arrow-up-s-fill text-xl"></i></span>
</div>

<div id="responsive-overlay"></div>

<!-- popperjs -->
<script src="<?php echo base_url('assets/libs/@popperjs/core/umd/popper.min.js'); ?>"></script>

<!-- Color Picker JS -->
<script src="<?php echo base_url('assets/libs/@simonwep/pickr/pickr.es5.min.js'); ?>"></script>

<!-- sidebar JS -->
<script src="<?php echo base_url('assets/js/defaultmenu.js'); ?>"></script>

<!-- sticky JS -->
<script src="<?php echo base_url('assets/js/sticky.js'); ?>"></script>

<!-- Switch JS -->
<script src="<?php echo base_url('assets/js/switch.js'); ?>"></script>

<!-- Preline JS -->
<script src="<?php echo base_url('assets/libs/preline/preline.js'); ?>"></script>

<!-- Simplebar JS -->
<script src="<?php echo base_url('assets/libs/simplebar/simplebar.min.js'); ?>"></script>

<?= $this->renderSection('scripts'); ?>

<!-- Custom JS -->
<script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>

<!-- Custom-Switcher JS -->
<script src="<?php echo base_url('assets/js/custom-switcher.js'); ?>"></script>

<!-- auto close alert -->
<!-- auto close alert -->
<script>
    setTimeout(function () {
        var toastContainer = document.querySelector('.toast-container');
        if (toastContainer) {
            toastContainer.style.transform = 'translateY(-200%)';
        }
    }, 3000);
</script>