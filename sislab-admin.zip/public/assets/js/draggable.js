(function () {
  "use strict";
  dragula([document.querySelector('#drag-left'),document.querySelector('#drag-center'), document.querySelector('#drag-right')]);
})();
